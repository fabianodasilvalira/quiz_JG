import type { Question } from "@/data/questions-structure"

export const copaDoMundoQuestions: Question[] = [
  {
    id: 301,
    question: "Qual seleção venceu a Copa do Mundo de 2022?",
    options: ["França", "Argentina", "Brasil"],
    correctAnswer: "Argentina",
    explanation:
      "A Argentina venceu a Copa do Mundo de 2022 no Qatar, derrotando a França nos pênaltis após empate por 3-3.",
    category: "copa_do_mundo",
    difficulty: "facil",
  },
  {
    id: 302,
    question: "Quem foi o artilheiro da Copa do Mundo de 2022?",
    options: ["Kylian Mbappé", "Lionel Messi", "Olivier Giroud"],
    correctAnswer: "Kylian Mbappé",
    explanation: "Mbappé foi o artilheiro da Copa do Mundo de 2022 com 8 gols, incluindo um hat-trick na final.",
    category: "copa_do_mundo",
    difficulty: "facil",
  },
  {
    id: 303,
    question: "Qual país sediou a primeira Copa do Mundo em 1930?",
    options: ["Brasil", "Uruguai", "Itália"],
    correctAnswer: "Uruguai",
    explanation: "O Uruguai sediou a primeira Copa do Mundo em 1930 e também foi o campeão.",
    category: "copa_do_mundo",
    difficulty: "medio",
  },
  {
    id: 304,
    question: "Qual seleção é a maior campeã da Copa do Mundo?",
    options: ["Brasil", "Alemanha", "Itália"],
    correctAnswer: "Brasil",
    explanation: "O Brasil é o maior campeão com 5 títulos (1958, 1962, 1970, 1994 e 2002).",
    category: "copa_do_mundo",
    difficulty: "facil",
  },
  {
    id: 305,
    question: "Qual jogador marcou mais gols em Copas do Mundo somando todas as edições?",
    options: ["Miroslav Klose", "Ronaldo Fenômeno", "Pelé"],
    correctAnswer: "Miroslav Klose",
    explanation: "Miroslav Klose marcou 16 gols em Copas do Mundo, sendo o maior artilheiro da história do torneio.",
    category: "copa_do_mundo",
    difficulty: "medio",
  },
  // Continuar com mais perguntas...
]


import type { Question } from "@/data/questions-structure"

export const brasileiraoQuestions: Question[] = [
  {
    id: 1,
    question: "Qual time é o maior campeão do Campeonato Brasileiro?",
    options: ["Palmeiras", "Flamengo", "Santos"],
    correctAnswer: "Palmeiras",
    explanation: "O Palmeiras é o maior campeão brasileiro com 11 títulos conquistados.",
    category: "brasileirao",
    difficulty: "facil",
  },
  {
    id: 2,
    question: "Qual jogador é o maior artilheiro da história do Campeonato Brasileiro?",
    options: ["Roberto Dinamite", "Romário", "Fred"],
    correctAnswer: "Roberto Dinamite",
    explanation: "Roberto Dinamite é o maior artilheiro da história do Brasileirão com 190 gols.",
    category: "brasileirao",
    difficulty: "medio",
  },
  {
    id: 3,
    question: "Em que ano foi disputado o primeiro Campeonato Brasileiro?",
    options: ["1959", "1971", "1967"],
    correctAnswer: "1971",
    explanation: "O primeiro Campeonato Brasileiro foi disputado em 1971, com o Atlético-MG como campeão.",
    category: "brasileirao",
    difficulty: "medio",
  },
  {
    id: 4,
    question: "Qual time foi campeão brasileiro de 2023?",
    options: ["Palmeiras", "Botafogo", "Flamengo"],
    correctAnswer: "Palmeiras",
    explanation: "O Palmeiras conquistou o Brasileirão de 2023 sob o comando de Abel Ferreira.",
    category: "brasileirao",
    difficulty: "facil",
  },
  {
    id: 5,
    question: "Qual foi o primeiro time nordestino a conquistar o Campeonato Brasileiro?",
    options: ["Bahia", "Sport", "Fortaleza"],
    correctAnswer: "Bahia",
    explanation: "O Bahia foi o primeiro time nordestino campeão brasileiro, em 1959 (considerando a Taça Brasil).",
    category: "brasileirao",
    difficulty: "medio",
  },
  // Continuar com mais perguntas...
]


import type { Question } from "@/data/questions-structure"

export const premierLeagueQuestions: Question[] = [
  {
    id: 201,
    question: "Qual clube venceu a Premier League na temporada 2022/23?",
    options: ["Arsenal", "Manchester City", "Liverpool"],
    correctAnswer: "Manchester City",
    explanation:
      "O Manchester City conquistou a Premier League 2022/23, seu terceiro título consecutivo sob o comando de Pep Guardiola.",
    category: "premier_league",
    difficulty: "facil",
  },
  {
    id: 202,
    question: "Qual jogador detém o recorde de mais gols em uma única temporada da Premier League (38 jogos)?",
    options: ["Mohamed Salah", "Alan Shearer", "Erling Haaland"],
    correctAnswer: "Erling Haaland",
    explanation: "Erling Haaland marcou 36 gols na temporada 2022/23, quebrando o recorde anterior.",
    category: "premier_league",
    difficulty: "facil",
  },
  {
    id: 203,
    question: "Qual clube inglês é conhecido como 'The Red Devils'?",
    options: ["Liverpool", "Manchester United", "Arsenal"],
    correctAnswer: "Manchester United",
    explanation: "Manchester United é conhecido como 'The Red Devils' (Os Diabos Vermelhos).",
    category: "premier_league",
    difficulty: "facil",
  },
  {
    id: 204,
    question: "Qual time foi o primeiro campeão da Premier League em sua era moderna (a partir de 1992)?",
    options: ["Manchester United", "Arsenal", "Blackburn Rovers"],
    correctAnswer: "Manchester United",
    explanation:
      "Manchester United foi o primeiro campeão da Premier League em 1992/93, sob o comando de Sir Alex Ferguson.",
    category: "premier_league",
    difficulty: "medio",
  },
  {
    id: 205,
    question: "Qual jogador tem mais assistências na história da Premier League?",
    options: ["Ryan Giggs", "Cesc Fàbregas", "Kevin De Bruyne"],
    correctAnswer: "Ryan Giggs",
    explanation: "Ryan Giggs detém o recorde de mais assistências na história da Premier League, com 162.",
    category: "premier_league",
    difficulty: "medio",
  },
  // Continuar com mais perguntas...
]


import type { Question } from "@/data/questions-structure"

export const jogadoresQuestions: Question[] = [
  {
    id: 101,
    question: "Qual jogador brasileiro ganhou a Bola de Ouro em 2007?",
    options: ["Ronaldinho Gaúcho", "Kaká", "Ronaldo Fenômeno"],
    correctAnswer: "Kaká",
    explanation: "Kaká foi o último brasileiro a ganhar a Bola de Ouro, em 2007, quando jogava pelo Milan.",
    category: "jogadores",
    difficulty: "facil",
  },
  {
    id: 102,
    question: "Quem é o maior artilheiro da história da Seleção Brasileira?",
    options: ["Pelé", "Neymar", "Ronaldo"],
    correctAnswer: "Neymar",
    explanation: "Neymar ultrapassou Pelé e se tornou o maior artilheiro da história da Seleção Brasileira.",
    category: "jogadores",
    difficulty: "facil",
  },
  {
    id: 103,
    question: "Qual jogador é conhecido como 'The Egyptian King'?",
    options: ["Mohamed Salah", "Riyad Mahrez", "Sadio Mané"],
    correctAnswer: "Mohamed Salah",
    explanation: "Mohamed Salah é chamado de 'The Egyptian King' (O Rei Egípcio) pelos torcedores do Liverpool.",
    category: "jogadores",
    difficulty: "facil",
  },
  {
    id: 104,
    question: "Qual jogador detém o recorde de mais gols em uma única edição do Campeonato Brasileiro?",
    options: ["Washington", "Fred", "Gabigol"],
    correctAnswer: "Washington",
    explanation: "Washington, o 'Coração Valente', marcou 34 gols pelo Athletico-PR no Brasileirão de 2004.",
    category: "jogadores",
    difficulty: "medio",
  },
  {
    id: 105,
    question: "Qual jogador marcou o gol mais rápido da história da Premier League?",
    options: ["Shane Long", "Alan Shearer", "Ledley King"],
    correctAnswer: "Shane Long",
    explanation: "Shane Long marcou após 7,69 segundos pelo Southampton contra o Watford em 2019.",
    category: "jogadores",
    difficulty: "dificil",
  },
  // Continuar com mais perguntas...
]

